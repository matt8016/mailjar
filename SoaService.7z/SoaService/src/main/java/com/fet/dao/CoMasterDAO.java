package com.fet.dao;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.fet.entity.CoMaster;
@Transactional
@Repository
public class CoMasterDAO implements ICoMasterDAO {

	public static final Logger logger = LoggerFactory.getLogger(CoMasterDAO.class);
	
	@Autowired
    private JdbcTemplate jdbcTemplate;
	
	@Override
	public CoMaster getCoMasterByCono(String cono) {

		logger.info("CoMasterDAO - getCoMasterByCono - Start. -----------------");
		
		StringBuilder sb = new StringBuilder(); 
		
		sb.append(" select cono, ");
		sb.append("             co_type, ");
		sb.append("             msisdn, ");
		sb.append("             promotioncode, ");
		sb.append("             promo_name, ");
		sb.append("             co_date, ");
		sb.append("             simcard_no, ");
		sb.append("             soasn, ");
		sb.append("             portin_date, ");
		sb.append("             np_company_code, ");
		sb.append("             coh_order_id, ");
		sb.append("             eform_trans_id, ");
		sb.append("             onsale_promo_list_id, ");
		sb.append("             tel1, ");
		sb.append("             user_name, ");
		sb.append("             roc_id, ");
		sb.append("             bill_addr ");
		sb.append(" from co_master ");
		sb.append(" where simcard_no is not null ");
		sb.append(" and cono = ? ");
		

		logger.info("CoMasterDAO - getCoMasterByCono :  parameter - cono : {}", cono);

		logger.info("CoMasterDAO - getCoMasterByCono :  sql : {}", sb.toString());
		
		RowMapper<CoMaster> rowMapper = new BeanPropertyRowMapper<CoMaster>(CoMaster.class);
		CoMaster coMaster = jdbcTemplate.queryForObject(sb.toString(), rowMapper, cono);
		

		logger.info("CoMasterDAO - getCoMasterByCono - End. -----------------");
		
		return coMaster;
	}
}
