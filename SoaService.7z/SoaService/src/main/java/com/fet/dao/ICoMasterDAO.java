package com.fet.dao;
import com.fet.entity.CoMaster;

public interface ICoMasterDAO {
    CoMaster getCoMasterByCono(String cono);
}
 