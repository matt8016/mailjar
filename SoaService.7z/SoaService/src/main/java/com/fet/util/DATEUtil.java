package com.fet.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * 處理日期資料的實用類別
 * @version 2019.04.08
 * @author YC
 */
public class DATEUtil {
  public DATEUtil() {
  }

  /**
   * 取得系統現在的八碼西元年日期
   * @return String - 回傳八碼西元年日期(yyyymmdd)字串
   */
  public static String create8Date() {
    String sReturn = "";
    sReturn = new SimpleDateFormat("yyyyMMdd").format(new Date());
    return sReturn;
  }
  /**
   * 取得系統現在的時間(時分秒)
   * @return String - 回傳時分秒(HHmmss)字串
   */
  public static String createHHmmss(){
    String sReturn = "";
    sReturn = new SimpleDateFormat("HHmmss").format(new Date());
    return sReturn;
  }

  /**
   * 取得某日期加上雙斜線後的日期格式
   * @param sDate String - 傳入七碼民國年日期字串 或 八碼西元年日期字串
   * @return String - 回傳雙斜線的九碼民國年日期(yyy/MM/dd), 或雙斜線的十碼西元年日期(yyyy/MM/dd), 或空字串
   */
  public static String addSlashDate(String sDate){
    if(sDate == null){
      return "";
    }
    else{
      if(sDate.length()==7){
        return sDate.substring(0, 3) + "/" + sDate.substring(3, 5) + "/" + sDate.substring(5);
      }
      else if(sDate.length()==8){
        return sDate.substring(0, 4) + "/" + sDate.substring(4, 6) + "/" + sDate.substring(6);
      }
      else{
        return sDate;
      }
    }
  }

  /**
   * 取得時間資料的雙冒號時間格式
   * @param sTime String - 傳入時間(HHmmss)
   * @return String - 回傳雙冒號時間格式(HH:mm:ss), 或空字串
   */
  public static String addColonTime(String sTime){
    if(sTime == null){
      return "";
    }
    else{
      if(sTime.length()==6){
        return sTime.substring(0, 2) + ":" + sTime.substring(2, 4) + ":" + sTime.substring(4);
      }
      else{
        return sTime;
      }
    }
  }
  
  /**
   * 取得某日期加幾天後的八碼西元年日期
   * @param date String - 傳入八碼西元年日期字串
   * @param day int - 傳入天數(正數:大於date,負數:小於date)
   * @return String - 回傳八碼西元年日期字串
   */
  public static String getShift8Date(String date, int day) {
    Date date1;
    Date date2 = new Date();
    try {
      DateFormat df = new SimpleDateFormat("yyyyMMdd", Locale.TAIWAN);
      date1 = df.parse(date);
      date2.setTime(date1.getTime() + (long) day * 24 * 60 * 60 * 1000);
    }
    catch (ParseException ex) {
      ex.printStackTrace();
      return null;
    }
    return new SimpleDateFormat("yyyyMMdd").format(date2);
  }
}
