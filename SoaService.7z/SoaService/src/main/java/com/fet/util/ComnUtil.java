package com.fet.util;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.List;
import java.util.Map;

@SuppressWarnings("rawtypes")
public class ComnUtil implements java.io.Serializable {

  private static final long serialVersionUID = 1L;

  public static String nvl(String str) {
    return (str == null || str.length() == 0) ? "" : str;
  }

  public static String nvl(String str, String replace) {
    return (str == null || str.length() == 0) ? replace : str;
  }

  public static boolean isNvlHm(Map ht) {
    return (ht == null || ht.size() == 0) ? true : false;
  }

  public static boolean isNvlLt(List lt) {
    return (lt == null || lt.size() == 0) ? true : false;
  }

  public static boolean isNvlStr(String[] str) {
    return (str == null || str.length == 0) ? true : false;
  }

  public static boolean isEmpty(String s) {
    return (s == null || s.length() == 0) ? true : false;
  }

  public static boolean isNumber(String strNumber) {
    boolean isSuccess = true;
    try {
      new Long(strNumber);
    } catch (NumberFormatException nfe) {
      isSuccess = false;
    } catch (Exception e) {
      isSuccess = false;
    }
    return isSuccess;
  }

  public static boolean isDouble(String strNumber) {
    boolean isSuccess = true;
    try {
      new Double(strNumber);
    } catch (NumberFormatException nfe) {
      isSuccess = false;
    } catch (Exception e) {
      isSuccess = false;
    }
    return isSuccess;
  }

  public static String getRound(String[] val, int arg) {
    if (isNvlStr(val) || arg < 1) return "";
    double total = 0;
    String result = "";
    try {
      for (int i = 0; i < val.length; i++) {
        total += Double.parseDouble(val[i]);
      }
      result = new BigDecimal(total / val.length).setScale(arg, BigDecimal.ROUND_HALF_EVEN).toString();
    } catch (Exception e) {
      return "";
    }
    return result;
  }

  public static String setStrToCurrency(String paramMoney) {
    if (isEmpty(paramMoney)) return "0";
    if (!isNumber(paramMoney)) return "0";

    NumberFormat nf = NumberFormat.getNumberInstance();
    return nf.format(Integer.parseInt(paramMoney));
  }

  public static String nvlObj(Object obj) {
    return (obj == null) ? "" : obj.toString();
  }
  
}
