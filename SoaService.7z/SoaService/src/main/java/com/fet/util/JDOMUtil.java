package com.fet.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.jdom.Attribute;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;

@SuppressWarnings({"unused","rawtypes"})
public class JDOMUtil {
  /**
   * 將 Element 物件輸出以便除錯
   * @param in	輸入的 Element 物件
   */
  public static void debug(Element in) {
    /*---- for jdom beta begin ----------
    //XMLOutputter outputter = new XMLOutputter(" ", true, "BIG5");
    XMLOutputter outputter = new XMLOutputter(" ", true, "UTF8");
    outputter.setTextNormalize(true);
    ---- for jdom beta end ----------*/
	XMLOutputter outputter = new XMLOutputter(Format.getPrettyFormat());
  }

  /**
   * 將 Element 物件輸出為String以便除錯
   * @param in	輸入的 Element 物件
   */
  public static String element2String(Element in) {
    if(in == null){ return new String(""); }
    /*---- for jdom beta begin ----------
    //XMLOutputter outputter = new XMLOutputter(" ", true, "BIG5");
    XMLOutputter outputter = new XMLOutputter(" ", true, "UTF8");
    outputter.setTextNormalize(true);
    ---- for jdom beta end ----------*/
    XMLOutputter outputter = new XMLOutputter(Format.getPrettyFormat());
    return outputter.outputString(in);
  }

  /**
   * 將 Element 物件輸出為String, 加上 XML宣告
   * @param in	輸入的 Element 物件
   */
  public static String element2StringExtra(Element in) {
    String sXml = JDOMUtil.element2String(in);
    sXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + sXml;
    return sXml;
  }

  /**
   * 取的xml Element 物件
   * @param Filename 要讀取的XML檔名
   */
  public Element genElementfromFile(String Filename) throws IOException,
      JDOMException {

    SAXBuilder builder = new SAXBuilder();
    Element root = null;
    try {
      // Build the JDOM Document
      //Document doc = builder.build(new File(Filename));
      InputStream in = getClass().getResourceAsStream(Filename);
      Document doc = builder.build(in);
      root = doc.getRootElement();
    }
    //catch (IOException ex) {
      //ex.printStackTrace();
      //throw new IOException("JDOMUtil.genElementfromFile() IO Exception !");
    //}
    catch (JDOMException ex) {
      ex.printStackTrace();
      throw new JDOMException("JDOMUtil.genElementfromFile() JDOM Exception !");
    }
    return root;
  }

  /**
   * 取的xml Element 物件
   * @param Xmlstring 要讀取的XML字串
   */
  public static Element genElementfromString(String Xmlstring) throws IOException,
      JDOMException {

    SAXBuilder builder = new SAXBuilder();
    Element root = null;
    try {
      // Build the JDOM Document
      Document doc = builder.build(new StringReader(Xmlstring));
      root = doc.getRootElement();
    }
    //catch (IOException ex) {
      //ex.printStackTrace();
      //throw new IOException("JDOMUtil.genElementfromString() IO Exception !");
    //}
    catch (JDOMException ex) {
      ex.printStackTrace();
      throw new JDOMException("JDOMUtil.genElementfromString() JDOM Exception !");
    }
    return root;
  }

  /**
   * 將 Element 物件輸出以便除錯
   * @param in	輸入的 Element 物件
   * @param debug debug 模式
   */
  public static void debug(Element in, boolean debug) {
    /*---- for jdom beta begin ----------
    //XMLOutputter outputter = new XMLOutputter(" ", true, "BIG5");
    XMLOutputter outputter = new XMLOutputter(" ", true, "UTF8");
    outputter.setTextNormalize(true);
    ---- for jdom beta end ----------*/
    XMLOutputter outputter = new XMLOutputter(Format.getPrettyFormat());
  }

  /**
   * 比較兩個 Element 是否相同
   */
  public static boolean compare(Element in, Element out, ArrayList skip) throws
      IOException {
    List compare = out.getChildren();
	Iterator compareIterator = compare.iterator();
    boolean foundSkip = false;
    while (compareIterator.hasNext()) {
      Element element = (Element) compareIterator.next();
      if (skip != null) {
        for (int i = 0; i < skip.size(); i++) {
          if (element.getName().equals(skip.get(i).toString())) { // skip comparation
            foundSkip = true;
            break;
          }
        }
        if (foundSkip) {
          foundSkip = false;
          continue;
        }
      }

      List listIn = in.getChildren(element.getName());
      List listOut = out.getChildren(element.getName());

      // 比較大小
      if (listIn.size() != listOut.size()) {
        System.out.println("在 " + element.getName() + " 這個目標內發現大小不同:");
        System.out.println("輸入大小 (children) = " + listIn.size()
                           + ", 輸出大小 (children) = " + listOut.size());
        return false;
      }

      Iterator listInIterator = listIn.iterator();
      Iterator listOutIterator = listOut.iterator();
      while (listInIterator.hasNext()) {
        Element listInElement = (Element) listInIterator.next();
        Element listOutElement = (Element) listOutIterator.next();
        if (!compare(listInElement, listOutElement, skip)) {
          return false;
        }
      }
    }
    return true;
  }

  /**
   * 取得 XPath
   */

  /**
   *	加入所有子項目
   */
  public static void addChildren(List children, Element target) {
    int size = children.size();
    for (int j = 0; j < size; j++) {
      Element child = (Element) children.get(j);
      target.addContent( (Element) child.clone());
    }
  }

  /**
   *	加入所有屬性
   */
  public static void addAttributes(List children, Element target) {
    int size = children.size();
    for (int j = 0; j < size; j++) {
      Attribute child = (Attribute) children.get(j);
      target.setAttribute( (Attribute) child.clone());
    }
  }

  /**
   *	加入所有子項目 (並排除已有的項目)
   */
  public static void addChildren(List children, Element target,
                                 boolean addDuplicate) {
    int size = children.size();
    for (int j = 0; j < size; j++) {
      Element child = (Element) children.get(j);
      if (addDuplicate || target.getChild(child.getName()) == null) {
        target.addContent( (Element) child.clone());
      }
      else {
        continue;
      }

    }
  }

  /**
   *	加入所有子項目,並移除原有編號



   */
  public static void addChildren(List children, Element target,
                                 boolean remove, String id) {
    int size = children.size();
    for (int j = 0; j < size; j++) {
      Element child = (Element) children.get(j);
      if (remove) {
        child.removeAttribute(id);
      }
      target.addContent( (Element) child.clone());
    }
  }
}
