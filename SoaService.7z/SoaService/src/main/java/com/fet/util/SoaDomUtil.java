package com.fet.util;
	
public class SoaDomUtil {
		
	/**
	 * 取得起訖日起 ticket 餘額
	 * @param opeartor FET, KGT, YZT( 重新申請 的業者)
	 * @param startDate YYYYMMDD
	 * @param endDate YYYYMMDD
	 * @return 回傳起訖日起 ticket 餘額
	 */
	public static String getPortingTicketBalanceQueryRequestXmlStr(String opeartor, String startDate, String endDate) {
		String portingStatusRequestXmlStr =		
					"<?xml version='1.0' encoding='UTF-8'?>" + 
					"<IA_REQUEST>" + 
					"	<ACTION>PORTING_TICKET_BALANCE_QUERY_REQUEST</ACTION>" + 
					"	<OPERATOR>" + opeartor + "</OPERATOR>" + 
					"	<START_DATE>" + startDate + "</START_DATE>" + 
					"	<END_DATE>" + endDate + "</END_DATE>" + 
					"</IA_REQUEST>";
		
		return portingStatusRequestXmlStr;
	}
	
	/**
	 * 取得查詢服務流水號狀態的 xml str : PORTING_STATUS_REQUEST
	 * @param msisdn 門號
	 * @param ticketNo 服務流水號
	 * @return  回傳 portingStatusRequestXmlStr
	 */
	public static String getPortingStatusRequestXmlStr(String msisdn, String ticketNo) {
		String portingStatusRequestXmlStr =		
					"<?xml version='1.0' encoding='UTF-8'?>" + 
					"<IA_REQUEST>" + 
					"	<ACTION>PORTING_STATUS_REQUEST</ACTION>" + 
					"	<MSISDN>" + msisdn + "</MSISDN>" + 
					"	<TID>" + ticketNo + "</TID>" + 
					"</IA_REQUEST>";
		
		return portingStatusRequestXmlStr;
	}
	
	/**
	 * 取得取消服務流水號的 xml str : PORTING_CANCEL_REQUEST
	 * @param opeartor FET, KGT, YZT( 重新申請 的業者)
	 * @param ticketNo 服務流水號
	 * @param cancelReason 取消原因代碼
	 * @return 回傳 portingCancelRequestXmlStr
	 */
	public static String getPortingCancelRequestXmlStr(String opeartor, String ticketNo, String cancelReason) {
		String portingCancelRequestXmlStr =		
					"<?xml version='1.0' encoding='UTF-8'?>" +
					"<IA_REQUEST>" + 
					"    <ACTION>PORTING_CANCEL_REQUEST</ACTION>" + 
					"    <OPERATOR>" + opeartor + "</OPERATOR>" + //FET, KGT, YZT( 重新申請 的業者)
					"    <TID>" + ticketNo + "</TID>" + 
					"    <CANCEL_REASON>" + cancelReason + "</CANCEL_REASON>" + //1 = User Cancel、2 = Operator Cancel、3 = Conflict Cancel
					"</IA_REQUEST>";
		
		return portingCancelRequestXmlStr;
	}
	
	/**
	 * 取得 Temp 服務流水號的 xml str : PORTING_TICKET_REQUEST
	 * @param opeartor FET, KGT, YZT(申請porting的業者)
	 * @param portOutOpeartor 移出業者
	 * @param msisdn 門號
	 * @param portingRequestDate 欲取的生效日期  ex:180320-3
	 * @return 回傳 portingTicketRequestXmlStr
	 */
	public static String getPortingTicketRequestXmlStr(String opeartor, String portOutOpeartor, String msisdn, String portingRequestDate) {
		String portingTicketRequestXmlStr = 
						"<?xml version='1.0' encoding='UTF-8'?>" +
						"<IA_REQUEST>" + 
						"    <ACTION>PORTING_TICKET_REQUEST</ACTION>" + 
						"    <OPERATOR>" + opeartor + "</OPERATOR>" + 
						"    <PORT_OUT_OPERATOR>" + portOutOpeartor + "</PORT_OUT_OPERATOR>" + 
						"    <MSISDN>" + msisdn + "</MSISDN>" + 
						"    <PORTING_REQUEST_DATE>" + portingRequestDate + "</PORTING_REQUEST_DATE>" +
						"</IA_REQUEST>";
				
		return portingTicketRequestXmlStr;
	}
	
	/**
	 * 取得 Submit 已取得的 Temp 服務流水號的 xml str : PORTING_SUBMIT_REQUEST
	 * @param portInOpeartor FET,KGT,YZT(移入業者)
	 * @param portOutOpeartor FET,KGT,TCC..(移出業者)
	 * @param msisdn 門號
	 * @param simNo sim card no : 尚不知 sim 時，先傳 99999999999999999999
	 * @param ticketNo 已取得的 Temp 服務流水號
	 * @param userName 申請人
	 * @param rocId 申請人證號
	 * @param applicationDateTime 申請日期時間 2018-03-16T11:35:41.552+08:00
	 * @param address 地址
	 * @param dTel 日間聯絡電話
	 * @param nTel 夜間聯絡電話
	 * @param portingRequestDate 已取得的 Temp 服務流水號的 預計生效日  ex:180320-3
	 * @param ivrCode 固定為 2801
	 * @param prodType 固定為 "Post-paid"
	 * @return 回傳 portingSubmitRequestXmlStr
	 */
	public static String getPortingSubmitRequestXmlStr(String portInOpeartor, String portOutOpeartor, String msisdn, String simNo, 
			String ticketNo, String userName, String rocId, String applicationDateTime, String address, String dTel, String nTel, 
			String portingRequestDate, String ivrCode, String prodType) {
		String portingSubmitRequestXmlStr = 
						"<?xml version='1.0' encoding='UTF-8'?>" +
						"<IA_REQUEST>" + 
						"    <ACTION>PORTING_SUBMIT_REQUEST</ACTION>" + 
						"    <PORT_IN_OPERATOR>" + portInOpeartor + "</PORT_IN_OPERATOR>" + 
						"    <PORT_OUT_OPERATOR>" + portOutOpeartor + "</PORT_OUT_OPERATOR>" + 
						"    <MSISDN>" + msisdn + "</MSISDN>" + 
						"    <SIM_NO>" + simNo + "</SIM_NO>" + 
						"    <SOA_SN>" + ticketNo + "</SOA_SN>" + 
						"    <CN>" + userName + "</CN>" + 
						"    <CID>" + rocId + "</CID>" + 
						"    <AD>" + applicationDateTime + "</AD>" + 
						"    <CA>" + address + "</CA>" + 
						"    <DCP>" + dTel + "</DCP>" + //日間聯絡電話
						"    <NCP>" + nTel + "</NCP>" + //夜間聯絡電話
						"    <PORTING_REQUEST_DATE>" + portingRequestDate + "</PORTING_REQUEST_DATE>" + 
						"    <IVRCODE>" + ivrCode + "</IVRCODE>" + 
						"    <PROD_TYPE>" + prodType + "</PROD_TYPE>" + //Post-paid
						"</IA_REQUEST>";

		return portingSubmitRequestXmlStr;
	}
	
	/**
	 * 取得移入業者 最近一天排除維護日 流水號餘額
	 * @param portInOpeartor 移入業者
	 * @return 回傳 queryMnpInfoQuotaXmlStr
	 */
	public static String getQueryMnpInfoQuotaXmlStr(String portInOpeartor) {
		String queryMnpInfoQuotaXmlStr = 
				"<SOA_REQUEST><OID>" + portInOpeartor + "</OID></SOA_REQUEST>";
		
		return queryMnpInfoQuotaXmlStr;
	}
	
}
