package com.fet.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fet.dao.ICoMasterDAO;
import com.fet.entity.CoMaster;
@Service
public class CoMasterService implements IGetNDateTicketService {

	public static final Logger logger = LoggerFactory.getLogger(CoMasterService.class);
	
	@Autowired
	private ICoMasterDAO coMasterDAO;
	
	@Override
	public CoMaster getCoMasterByCono(String cono) {

		logger.info("CoMasterService - getCoMasterByCono - Start. -----------------");
		
		CoMaster obj = coMasterDAO.getCoMasterByCono(cono);

		logger.info("CoMasterService - getCoMasterByCono - End. -----------------");
		return obj;
	}
}
