package com.fet.service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;

import org.jdom.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.fet.entity.SoaMessage;
import com.fet.util.JDOMUtil;


@SuppressWarnings("rawtypes")
@Service("SoaService")
public class SoaService implements ISoaService{
	public static final Logger logger = LoggerFactory.getLogger(SoaService.class);
	
	/*
	public static void main(String[] args) {
		SoaService soaService = new SoaServiceImpl();
		String msisdn = "0929314469";
		String ticketNo = "M-FE4-0000-CH4-0000-190403-A747"; //"M-FE4-0000-CH4-0000-190402-C144";
		//---------------------------------------------------------------
		String opeartor  = "FE4";
		String portOutOpeartor = "CH4";
		String portingRequestDate = "190408-3";
		//---------------------------------------------------------------
		String simNo = "99999999999999999999";
		String portInOpeartor = "FE4";
		String userName = "李蘭馨";
		String rocId = "Q221501295";
		String applicationDateTime = "2019-04-03T13:11:41.552+08:00";
		String address = "嘉義縣布袋鎮太平路１２０號之１";
		String dTel = "0929314469";
		String nTel = "0929314469";
		String ivrCode = "2801";
		String prodType = "Post-paid";
		//TG190328001347

		//查詢 ticket 狀態
		soaService.portintStatusRequest(SoaDomUtil.getPortingStatusRequestXmlStr(msisdn, ticketNo));
		
		//查詢 移入業者 最近日期有 ticket 餘額的
		//soaService.queryMnpInfoQuota(SoaDomUtil.getQueryMnpInfoQuotaXmlStr("FE4") );
		
		//soaService.portingTicketRequest(SoaDomUtil.getPortingTicketRequestXmlStr(opeartor, portOutOpeartor, msisdn, portingRequestDate));
		
		//soaService.portingSubmitRequest(SoaDomUtil.getPortingSubmitRequestXmlStr(portInOpeartor, portOutOpeartor, msisdn, simNo, "M-FE4-0000-CH4-0000-190403-A747", userName, rocId, applicationDateTime, address, dTel, nTel, portingRequestDate, ivrCode, prodType));
	}
	*/
	
/*
	public static void main(String[] args) {
		SoaService soaService = new SoaServiceImpl();
		soaService.portingTicketBalanceQueryRequest(SoaDomUtil.getPortingTicketBalanceQueryRequestXmlStr("FE4", DATEUtil.getShift8Date(DATEUtil.create8Date(), 5), DATEUtil.getShift8Date(DATEUtil.create8Date(), 10)));
	}
	*/
	private static final String strUrl ="http://10.68.72.6:7003/np_api/submitIARequest.do";
	
	public SoaMessage portingTicketBalanceQueryRequest(String reqStr, SoaMessage soaMessage) {
		String resStr = "";
		String returnValue = "";
		
		try {  
			logger.info("portingTicketBalanceQueryRequest Start. --------------------------------");
			soaMessage.setAction("PORTING_TICKET_BALANCE_QUERY_REQUEST");
			
			logger.info("SOA - API portintStatusRequest request :  API portingTicketBalanceQueryRequest strUrl : {}", strUrl);
			logger.info("SOA - API portingTicketBalanceQueryRequest request :  API request : {}", reqStr);
			
            resStr = this.postSoaProccess(reqStr, strUrl);
            
            List list =JDOMUtil.genElementfromString(resStr).getChildren();
            String returnCode = "";
            
	        for(int j = 0 ; j < list.size() ; j++) {
	        	Element element = (Element)list.get(j);
	        	String eleName = element.getName();
	        	if("RETURN_CODE".equals(eleName)) {
	        		returnCode = element.getValue();
	        		soaMessage.setReturnCode(returnCode);
	        		if("0".equals(returnCode)) { //Successful
	        			List childrenList = JDOMUtil.genElementfromString(resStr).getChildren("PORTING_DATE");
	        			for(int x = 0 ; x < childrenList.size() ; x++) {
	        				Element childrenElement = (Element)childrenList.get(x);
	        				if(Integer.parseInt(childrenElement.getChildText("TOTAL_BALANCE")) > 0) {
	        					returnValue = childrenElement.getChildText("PORTING_REQUEST_DATE");
	        					soaMessage.setPortinDate(returnValue);
	        					break;
	        				}  		        				
	        			}
	        		}else {
	        			break;
		        	}
	        	}
	        	if("DESCRIPTION".equals(eleName)) {
	        		soaMessage.setDescription(element.getValue());
	        	}
	        }
			logger.info("SOA - API portintStatusRequest respondes :  API respondes : {}", resStr);
			
		}catch (Exception e) {  
            System.out.println("\nError while calling DemoWS REST Service");  
    		logger.info(e.toString());
		} 
		return soaMessage;
	}
	
	public  SoaMessage portingTicketRequest(String reqStr, SoaMessage soaMessage){
		String resStr = "";
		String returnCode = "";
		String ticketNo = "";
		
		try {  
			logger.info("portingTicketRequest Start. --------------------------------");
			soaMessage.setAction("PORTING_TICKET_REQUEST");
			
			logger.info("portingTicketRequest strUrl : ", strUrl);
			logger.info("SOA - API portingTicketRequest request :  API request : {}", reqStr);

            resStr = this.postSoaProccess(reqStr, strUrl);

            boolean success = false;
			List list =JDOMUtil.genElementfromString(resStr).getChildren();
	        for(int i = 0 ; i < list.size() ; i++) {
	        	Element element = (Element)list.get(i);
	        	String eleName = element.getName();
	        	if("RETURN_CODE".equals(eleName)) {
	        		returnCode = element.getValue();
	        		soaMessage.setReturnCode(returnCode);
	        		if("0".equals(returnCode)) {
	        			success = true;
	        		}
	        	}
	        	if(success && "SOA_SN".equals(eleName)) {
	        		ticketNo = element.getValue();
	        		soaMessage.setSoasn(ticketNo);
	        	}
	        	if("DESCRIPTION".equals(eleName)) {
	        		soaMessage.setDescription(element.getValue());
	        	}
	        }
            
			logger.info("SOA - API portingTicketRequest respondes :  API respondes : {}", resStr);
		} catch (Exception e) {  
            System.out.println("\nError while calling DemoWS REST Service");  
    		logger.info(e.toString());
        } 
		logger.info("portingTicketRequest End. --------------------------------");
		return soaMessage;
	}
	
	public SoaMessage portingSubmitRequest(String reqStr, SoaMessage soaMessage){
		String resStr = "";
		String returnCode = "";
		
		try {  
			logger.info("portingSubmitRequest Start. --------------------------------");
			soaMessage.setAction("PORTING_SUBMIT_REQUEST");
			
			logger.info("portingSubmitRequest strUrl : ", strUrl);
			logger.info("SOA - API portingSubmitRequest request :  API request : {}", reqStr);

            resStr = this.postSoaProccess(reqStr, strUrl);

            List list =JDOMUtil.genElementfromString(resStr).getChildren();
	        for(int i = 0 ; i < list.size() ; i++) {
	        	Element element = (Element)list.get(i);
	        	String eleName = element.getName();
	        	if("RETURN_CODE".equals(element.getName())) {
	        		returnCode = element.getValue();
	        		soaMessage.setReturnCode(returnCode);
	        		if("0".equals(returnCode)) {
	        			logger.info("SOA - API portingSubmitRequest respondes :  API returnCode : {}", returnCode);
	        		}
	        	}
	        	if("DESCRIPTION".equals(eleName)) {
	        		soaMessage.setDescription(element.getValue());
	        	}
	        }
			logger.info("SOA - API portingSubmitRequest respondes :  API respondes : {}", resStr);
		} catch (Exception e) {  
            System.out.println("\nError while calling DemoWS REST Service");  
    		logger.info(e.toString());
        } 
		logger.info("portingSubmitRequest End. --------------------------------");
		
		return soaMessage;
	}
			
	private String postSoaProccess(String reqStr, String strUrl) {
		String resStr = "";
		try {

			logger.info("SOA - API postSoaProccess :  API reqStr : {}", reqStr);
			
			URL url = new URL(strUrl);  
	        URLConnection connection = url.openConnection();  
	        
	        //connection.setRequestProperty("Content-Type", "application/xml");
	        connection.setConnectTimeout(5000);  
	        connection.setReadTimeout(5000);  
	        connection.setDoOutput(true);
	        OutputStreamWriter out = new OutputStreamWriter(connection.getOutputStream());
	        
	        out.write(reqStr);
	        out.close();  
	        
	        BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));  
	        
	        StringBuffer sb = new StringBuffer();            
	        String line = null;  
	        while ((line=in.readLine()) != null) {
	        	sb.append(line);
	        }
	        in.close();  
	        resStr = sb.toString();
		}catch (Exception e) {  
	            System.out.println("\nError while calling DemoWS REST Service");  
	    		logger.info(e.toString());
	    } 
		return resStr;
	}
}
