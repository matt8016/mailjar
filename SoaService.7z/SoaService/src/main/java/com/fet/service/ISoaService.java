package com.fet.service;

import com.fet.entity.SoaMessage;

public interface ISoaService {
		
	SoaMessage portingTicketRequest(String reqStr, SoaMessage soaMessage);
	
	SoaMessage portingSubmitRequest(String reqStr, SoaMessage soaMessage);
	
	SoaMessage portingTicketBalanceQueryRequest(String reqStr, SoaMessage soaMessage);
}
