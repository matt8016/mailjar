package com.fet.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fet.dao.ICoMasterDAO;
import com.fet.entity.CoMaster;
@Service
public class GetNDateTicketService implements IGetNDateTicketService {
	@Autowired
	private ICoMasterDAO coMasterDAO;
	
	@Override
	public CoMaster getCoMasterByCono(String cono) {
		CoMaster obj = coMasterDAO.getCoMasterByCono(cono);
		return obj;
	}
}
