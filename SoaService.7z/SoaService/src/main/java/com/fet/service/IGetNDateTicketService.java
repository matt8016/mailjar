package com.fet.service;

import com.fet.entity.CoMaster;

public interface IGetNDateTicketService {
	public CoMaster getCoMasterByCono(String cono);
}
