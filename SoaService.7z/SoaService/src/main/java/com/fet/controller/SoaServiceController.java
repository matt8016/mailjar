package com.fet.controller;
import java.time.LocalDateTime;

import org.jdom.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.fet.entity.CoMaster;
import com.fet.entity.SoaMessage;
import com.fet.service.CoMasterService;
import com.fet.service.SoaService;
import com.fet.util.ComnUtil;
import com.fet.util.DATEUtil;
import com.fet.util.JDOMUtil;
import com.fet.util.SoaDomUtil;

@Controller
@RequestMapping("/soa")
public class SoaServiceController {
	public static final Logger logger = LoggerFactory.getLogger(SoaServiceController.class);
	
	@Autowired
	private CoMasterService coMasterService;
	/*
	public static void main(String[] args) {
		SoaServiceController soaServiceController = new SoaServiceController();
		soaServiceController.getNDateTicketService("TG190415916603M", 2);
	}
	*/
	@RequestMapping(value = "/getNDateTicketService", method = RequestMethod.POST)
	public ResponseEntity<?> getNDateTicketService(@RequestParam("cono") String cono, 
			@RequestParam("addDay") int addDay) {

		logger.info("SoaService - API getNDateTicketService - Start. -----------------");
		logger.info("SoaService - API getNDateTicketService :  parameter - cono, addDay : {}", cono + ", " + addDay);
		String respondesXml = "";

		Element soaResponse = new Element("SOA_RESPONSE");
		if(!ComnUtil.isEmpty(cono)) {
			CoMaster coMaster = coMasterService.getCoMasterByCono(cono.trim());
			String coType = coMaster.getCoType();
			String portOutOpeartor = coMaster.getNpCompanyCode();
			String msisdn = coMaster.getMsisdn();
			String simcardNo = coMaster.getSimcardNo();
			String userName = coMaster.getUserName();
			String rocId = coMaster.getRocId();
			String billAddr = coMaster.getBillAddr();
			String tel = coMaster.getTel1();

			if(!ComnUtil.isEmpty(coType)) {
				if("PC".equals(coType) || "PH".equals(coType)) {
					SoaService soaService = new SoaService();
					SoaMessage soaMessage = new SoaMessage();
					String sysDate = DATEUtil.create8Date();
					String returnCode = "";
					
					soaMessage = soaService.portingTicketBalanceQueryRequest(SoaDomUtil.getPortingTicketBalanceQueryRequestXmlStr("FE4", DATEUtil.getShift8Date(sysDate, addDay), DATEUtil.getShift8Date(sysDate, addDay+5)), soaMessage);
					returnCode = soaMessage.getReturnCode();
					if(!ComnUtil.isEmpty(soaMessage.getReturnCode()) && "0".equals(returnCode)) { //取得有餘額的日期值
						soaMessage = soaService.portingTicketRequest(SoaDomUtil.getPortingTicketRequestXmlStr("FE4", portOutOpeartor, msisdn, soaMessage.getPortinDate()), soaMessage);
						String reqTicketNo = soaMessage.getSoasn();
						if(!ComnUtil.isEmpty(reqTicketNo)) {
							soaMessage = soaService.portingSubmitRequest(SoaDomUtil.getPortingSubmitRequestXmlStr("FE4", portOutOpeartor, msisdn, simcardNo, reqTicketNo, userName, rocId, (LocalDateTime.now()).toString() + "+08:00", billAddr, tel, tel, soaMessage.getPortinDate(), "2801", "Post-paid"), soaMessage);
						}
					}
										
					soaResponse.addContent(new Element("ACTION").setText(soaMessage.getAction()));
					soaResponse.addContent(new Element("RETURN_CODE").setText(returnCode));
					soaResponse.addContent(new Element("DESCRIPTION").setText(soaMessage.getDescription()));
					soaResponse.addContent(new Element("SOASN").setText(soaMessage.getSoasn()));
					soaResponse.addContent(new Element("PORTIN_DATE").setText(soaMessage.getPortinDate()));
					
				}
			}
		}else {
			soaResponse.addContent(new Element("RETURN_CODE").setText("ERROR_0001"));
			soaResponse.addContent(new Element("DESCRIPTION").setText("訂單編號不可為空值"));
		}
		respondesXml = JDOMUtil.element2StringExtra(soaResponse);
		logger.info("SoaService - API getNDateTicketService response XML -  : {} ",  respondesXml);
		logger.info("SoaService - API getNDateTicketService - End. -----------------");
		
		return new ResponseEntity<>(respondesXml, HttpStatus.OK);
	}
} 