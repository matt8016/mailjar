package com.fet.entity;

public class CoMaster { 
    private String cono;  
    private String coType;
	private String coDate;
	private String msisdn;
	private String promotioncode;
	private String promoName;
	private String simcardNo;
	private String soasn;
	private String portinDate;
	private String npCompanyCode;
	private String cohOrderId;
	private String eformTransId;
	private String onsalePromoListId;
	private String tel1;
	private String userName;
	private String billAddr;
	private String rocId;
	
	public String getCono() {
		return cono;
	}
	public void setCono(String cono) {
		this.cono = cono;
	}
	public String getCoType() {
		return coType;
	}
	public void setCoType(String coType) {
		this.coType = coType;
	}
	public String getCoDate() {
		return coDate;
	}
	public void setCoDate(String coDate) {
		this.coDate = coDate;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public String getPromotioncode() {
		return promotioncode;
	}
	public void setPromotioncode(String promotioncode) {
		this.promotioncode = promotioncode;
	}
	public String getPromoName() {
		return promoName;
	}
	public void setPromoName(String promoName) {
		this.promoName = promoName;
	}
	public String getSoasn() {
		return soasn;
	}
	public void setSoasn(String soasn) {
		this.soasn = soasn;
	}
	public String getPortinDate() {
		return portinDate;
	}
	public void setPortinDate(String portinDate) {
		this.portinDate = portinDate;
	}
	public String getSimcardNo() {
		return simcardNo;
	}
	public void setSimcardNo(String simcardNo) {
		this.simcardNo = simcardNo;
	}
	public String getCohOrderId() {
		return cohOrderId;
	}
	public void setCohOrderId(String cohOrderId) {
		this.cohOrderId = cohOrderId;
	}
	public String getNpCompanyCode() {
		return npCompanyCode;
	}
	public void setNpCompanyCode(String npCompanyCode) {
		this.npCompanyCode = npCompanyCode;
	}
	public String getEformTransId() {
		return eformTransId;
	}
	public void setEformTransId(String eformTransId) {
		this.eformTransId = eformTransId;
	}
	public String getOnsalePromoListId() {
		return onsalePromoListId;
	}
	public void setOnsalePromoListId(String onsalePromoListId) {
		this.onsalePromoListId = onsalePromoListId;
	}
	public String getTel1() {
		return tel1;
	}
	public void setTel1(String tel1) {
		this.tel1 = tel1;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getBillAddr() {
		return billAddr;
	}
	public void setBillAddr(String billAddr) {
		this.billAddr = billAddr;
	}
	public String getRocId() {
		return rocId;
	}
	public void setRocId(String rocId) {
		this.rocId = rocId;
	}
} 