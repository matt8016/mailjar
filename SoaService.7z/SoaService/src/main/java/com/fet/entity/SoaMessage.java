package com.fet.entity;

public class SoaMessage { 
	private String action;
	private String returnCode;
	private String description;
	private String soasn;
	private String portinDate;
	
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getReturnCode() {
		return returnCode;
	}
	public void setReturnCode(String returnCode) {
		this.returnCode = returnCode;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getSoasn() {
		return soasn;
	}
	public void setSoasn(String soasn) {
		this.soasn = soasn;
	}
	public String getPortinDate() {
		return portinDate;
	}
	public void setPortinDate(String portinDate) {
		this.portinDate = portinDate;
	}
} 