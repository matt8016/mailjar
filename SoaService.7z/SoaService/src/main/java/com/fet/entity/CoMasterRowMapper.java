package com.fet.entity;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class CoMasterRowMapper implements RowMapper<CoMaster> {

	@Override
	public CoMaster mapRow(ResultSet row, int rowNum) throws SQLException {
		CoMaster coMaster = new CoMaster();
		coMaster.setCono(row.getString("cono"));
		coMaster.setCoType(row.getString("co_type"));
		coMaster.setCoDate(row.getString("co_date"));
		coMaster.setMsisdn(row.getString("msisdn"));
		coMaster.setPromotioncode(row.getString("promotioncode"));
		coMaster.setPromoName(row.getString("promo_name"));
		coMaster.setSimcardNo(row.getString("simcard_no"));
		coMaster.setSoasn(row.getString("soasn"));
		coMaster.setPortinDate(row.getString("portin_date"));
		coMaster.setNpCompanyCode(row.getString("np_company_code"));
		coMaster.setCohOrderId(row.getString("coh_order_id"));
		coMaster.setEformTransId(row.getString("eform_trans_id"));
		coMaster.setOnsalePromoListId(row.getString("onsale_promo_list_id"));
		coMaster.setTel1(row.getString("tel1"));
		coMaster.setUserName(row.getString("user_name"));
		coMaster.setRocId("roc_id");
		coMaster.setBillAddr(row.getString("bill_addr"));
		return coMaster;
	}

}
