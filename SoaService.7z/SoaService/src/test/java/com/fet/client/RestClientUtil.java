package com.fet.client;

public class RestClientUtil {
    public static void main(String args[]) {
        //util.getArticleByIdDemo();
    	//util.addArticleDemo();
    	//util.updateArticleDemo();
    	//util.deleteArticleDemo();
    }    
}
